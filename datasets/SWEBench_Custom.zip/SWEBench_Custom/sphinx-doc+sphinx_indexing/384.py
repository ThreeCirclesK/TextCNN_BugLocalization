project = 'versioning test root'
source_suffix = '.txt'
exclude_patterns = ['_build']
