from spam.mod1 import Class3
__all__ = ('Class3',)
