exclude_patterns = ['_build']
html_search_language = 'en'
