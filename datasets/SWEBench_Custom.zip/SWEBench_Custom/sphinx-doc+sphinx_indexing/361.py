#!python
# -*- coding: windows-1251 -*-

X="�" #:It MUST look like X="�"