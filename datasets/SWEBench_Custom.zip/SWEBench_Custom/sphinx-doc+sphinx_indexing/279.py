import sys

# Fail module import in a catastrophic way
sys.exit(1)
