from setuptools import setup


setup(name='sample',
      py_modules=['sample'])
