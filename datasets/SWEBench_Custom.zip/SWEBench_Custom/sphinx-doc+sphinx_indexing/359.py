#: constant on sample.py
CONSTANT = 1


def hello(s):
    print('Hello %s' % s)
