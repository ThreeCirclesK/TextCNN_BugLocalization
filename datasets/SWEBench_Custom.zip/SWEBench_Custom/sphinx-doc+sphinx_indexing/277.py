class Foo:
    """docstring of Foo."""

    def meth(self):
        """docstring of meth."""
        pass

    def skipmeth(self):
        """docstring of skipmeth."""
        pass

    def _privatemeth(self):
        """docstring of _privatemeth."""
        pass
