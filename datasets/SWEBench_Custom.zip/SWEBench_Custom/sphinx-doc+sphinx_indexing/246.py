class Cls:
    def method(self):
        """Method docstring"""
        pass


bound_method = Cls().method
