import unknown


class Foo(unknown.Class):
    """Foo class"""
    pass
