project = 'Sphinx smallest project'
source_suffix = '.txt'
keep_warnings = True
exclude_patterns = ['_build']
