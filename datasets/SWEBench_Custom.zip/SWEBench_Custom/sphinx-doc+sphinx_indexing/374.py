html_theme = 'test-theme'
html_theme_path = ['.', 'test_theme']
exclude_patterns = ['_build']
