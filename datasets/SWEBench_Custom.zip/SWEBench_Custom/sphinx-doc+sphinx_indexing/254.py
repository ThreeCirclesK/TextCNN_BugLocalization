from .partialfunction import func2, func3
