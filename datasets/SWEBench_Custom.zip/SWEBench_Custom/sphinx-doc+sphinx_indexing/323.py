exclude_patterns = ['_build']

rst_epilog = '''
.. |picture| image:: pic.png
    :height: 1cm
    :scale: 200%
    :align: middle
    :alt: alternative_text
'''
