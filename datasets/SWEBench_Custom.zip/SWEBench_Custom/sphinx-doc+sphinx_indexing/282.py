class Documented:
    """Documented"""

    def ignored1(self):
        pass

    def ignored2(self):
        pass

    def not_ignored1(self):
        pass

    def not_ignored2(self):
        pass


class Ignored:
    pass


class NotIgnored:
    pass
